-- =============================================================================
-- REPOSITORY: Google_Meta_AdSpend_Analytics
-- FILE: /sql/roas_and_spend_efficiency.sql
-- DESCRIPTION: Cross-channel paid media performance queries evaluating CAC,
--              ROAS, diminishing marginal returns, and wasted ad spend.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. CROSS-CHANNEL FUNNEL EFFICIENCY & UNIT METRICS BY PLACEMENT
-- Evaluates full-funnel efficiency (CPM, CTR, CPC, CPL, Cost per SQL, CAC, ROAS)
-- across Google Ads and Meta Ads placements.
-- -----------------------------------------------------------------------------
SELECT
    Platform,
    Funnel_Stage,
    Placement,
    ROUND(SUM(Spend_USD), 2) AS Total_Spend_USD,
    SUM(Impressions) AS Total_Impressions,
    SUM(Clicks) AS Total_Clicks,
    SUM(Leads) AS Total_Leads,
    SUM(Qualified_SQLs) AS Total_SQLs,
    SUM(Conversions) AS Total_Conversions,
    ROUND(SUM(Revenue_USD), 2) AS Total_Revenue_USD,
    ROUND((SUM(Spend_USD) / NULLIF(SUM(Impressions), 0)) * 1000.0, 2) AS CPM_USD,
    ROUND((CAST(SUM(Clicks) AS FLOAT) / NULLIF(SUM(Impressions), 0)) * 100.0, 2) AS CTR_Pct,
    ROUND(SUM(Spend_USD) / NULLIF(SUM(Clicks), 0), 2) AS CPC_USD,
    ROUND(SUM(Spend_USD) / NULLIF(SUM(Leads), 0), 2) AS CPL_USD,
    ROUND(SUM(Spend_USD) / NULLIF(SUM(Conversions), 0), 2) AS Blended_CAC_USD,
    ROUND(SUM(Revenue_USD) / NULLIF(SUM(Spend_USD), 0), 2) AS ROAS_Multiplier
FROM cross_channel_ad_spend_daily
GROUP BY Platform, Funnel_Stage, Placement
ORDER BY ROAS_Multiplier DESC;


-- -----------------------------------------------------------------------------
-- 2. WASTED SPEND & ZERO-CONVERSION AD SET DETECTION
-- Isolates specific campaign dates and placements burning budget with zero
-- closed conversions or sub-1.0x ROAS for immediate Q4 reallocation.
-- -----------------------------------------------------------------------------
WITH CampaignWeekly AS (
    SELECT
        Platform,
        Campaign_ID,
        Campaign_Name,
        Placement,
        COUNT(Date) AS Active_Days,
        SUM(CASE WHEN Conversions = 0 THEN 1 ELSE 0 END) AS Zero_Conversion_Days,
        ROUND(SUM(CASE WHEN Conversions = 0 THEN Spend_USD ELSE 0 END), 2) AS Zero_Conv_Wasted_Spend_USD,
        ROUND(SUM(Spend_USD), 2) AS Total_Campaign_Spend_USD,
        SUM(Conversions) AS Total_Conversions,
        ROUND(SUM(Revenue_USD) / NULLIF(SUM(Spend_USD), 0), 2) AS Campaign_ROAS
    FROM cross_channel_ad_spend_daily
    GROUP BY Platform, Campaign_ID, Campaign_Name, Placement
)
SELECT
    Platform,
    Campaign_ID,
    Campaign_Name,
    Placement,
    Active_Days,
    Zero_Conversion_Days,
    Zero_Conv_Wasted_Spend_USD,
    Total_Campaign_Spend_USD,
    ROUND((Zero_Conv_Wasted_Spend_USD / NULLIF(Total_Campaign_Spend_USD, 0)) * 100.0, 2) AS Wasted_Spend_Share_Pct,
    Total_Conversions,
    Campaign_ROAS
FROM CampaignWeekly
ORDER BY Zero_Conv_Wasted_Spend_USD DESC;


-- -----------------------------------------------------------------------------
-- 3. DIMINISHING MARGINAL RETURNS & DAILY SPEND TIER ANALYSIS
-- Buckets daily campaign spend into quartiles using NTILE(4) to detect where
-- incremental budget scaling inflates CAC and compresses ROAS.
-- -----------------------------------------------------------------------------
WITH SpendQuartiles AS (
    SELECT
        Platform,
        Campaign_Name,
        Date,
        Spend_USD,
        Conversions,
        Revenue_USD,
        NTILE(4) OVER (PARTITION BY Campaign_Name ORDER BY Spend_USD ASC) AS Spend_Quartile
    FROM cross_channel_ad_spend_daily
)
SELECT
    Platform,
    Campaign_Name,
    Spend_Quartile,
    ROUND(MIN(Spend_USD), 2) AS Min_Daily_Spend_USD,
    ROUND(MAX(Spend_USD), 2) AS Max_Daily_Spend_USD,
    ROUND(AVG(Spend_USD), 2) AS Avg_Daily_Spend_USD,
    SUM(Conversions) AS Quartile_Conversions,
    ROUND(SUM(Spend_USD) / NULLIF(SUM(Conversions), 0), 2) AS Marginal_CAC_USD,
    ROUND(SUM(Revenue_USD) / NULLIF(SUM(Spend_USD), 0), 2) AS Quartile_ROAS
FROM SpendQuartiles
GROUP BY Platform, Campaign_Name, Spend_Quartile
ORDER BY Platform, Campaign_Name, Spend_Quartile;
